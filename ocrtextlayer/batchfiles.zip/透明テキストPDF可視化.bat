@echo off
if "%~2" == "" goto usage
if not "%~3" == "" goto usage
goto main

:usage
echo.
echo �g�p���@�F %~nx0  ����.pdf  �o��.pdf
goto :eof

:main
echo on
qpdf --qdf --object-streams=disable %1 ~temp1.qdf
sd -f w "3 Tr" "0 Tr" < ~temp1.qdf | sd " /ca 0" " /ca 1" | sd -f w "[0-9] [0-9] [0-9] rg" "0 0 0 rg" > ~temp2.qdf
cpdf -squeeze ~temp2.qdf -o %2
del ~temp1.qdf
del ~temp2.qdf
