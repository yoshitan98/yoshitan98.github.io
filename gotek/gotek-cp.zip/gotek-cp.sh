#!/bin/bash

# ==========================================
# Gotek スロット間ダイレクトコピー・スクリプト
# ==========================================

# Windows上で "bash.exe -c スクリプト" のショートカットで使えるようにパラメーター指定をインターラクティブにして "Press Enter." を追加。

# デバイス名を取得するため 3913728 のように常用するUSBメモリのサイズを書いておく
USBDEV=$(cat /proc/partitions | grep -E "3913728 sd[a-z]$")
if [ $? -eq 1 ]; then
    echo 常用USBメモリーが取り付けられていません。Press Enter.
    read
    exit 1
fi
USBDEV=/dev/${USBDEV: -3}

read -p "コピー元番号(0-999)は？ " FROM_SLOT
if ! [[ "$FROM_SLOT" =~ ^[0-9]+$ ]] || [ "$FROM_SLOT" -lt 0 -o "$FROM_SLOT" -gt 999 ]; then
    echo "エラー: コピー元番号（$1）は0から999の間で指定してください。Press Enter."
    read
    exit 2
fi

read -p "コピー先番号(0-999)は？ " TO_SLOT
if ! [[ "$TO_SLOT" =~ ^[0-9]+$ ]] || [ "$TO_SLOT" -lt 0 -o "$TO_SLOT" -gt 999 ]; then
    echo "エラー: コピー先番号（$2）は0から999の間で指定してください。Press Enter."
    read
    exit 3
fi

IMGOFFSET=3072   # Gotekの区画間隔（ブロック数）
FDDBLOCKS=2880   # フロッピー1枚のデータサイズ（ブロック数）

SRC_OFFSET=$(( $FROM_SLOT * $IMGOFFSET ))
DST_OFFSET=$(( $TO_SLOT * $IMGOFFSET ))

echo "USBメモリー（$USBDEV）の Slot-$FROM_SLOT から Slot-$TO_SLOT へデータをコピー中..."

dd if="$USBDEV" bs=512 skip=$SRC_OFFSET count=$FDDBLOCKS 2>/dev/null | \
dd of="$USBDEV" bs=512 seek=$DST_OFFSET count=$FDDBLOCKS 2>/dev/null

if [ $? -eq 0 ]; then
    echo "コピーが正常に完了しました！Press Enter."
else
    echo "エラー: コピーに失敗しました。管理者権限等を確認してください。Press Enter."
fi
read