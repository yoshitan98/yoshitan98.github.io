# cfgファイルのdrumset行にドラムセット名をコメントとして書く
# 2025/9/17 Copilotに作成させて、それをを少し変更

import struct
import sys
import re

def extract_drumset_names(sf2_path):
    with open(sf2_path, 'rb') as f:
        data = f.read()

    def read_chunk_header(offset):
        chunk_id = data[offset:offset+4].decode('ascii', errors='ignore')
        size = struct.unpack('<I', data[offset+4:offset+8])[0]
        return chunk_id, size, offset + 8

    def find_pdta_chunks():
        offset = 12
        while offset < len(data):
            chunk_id, size, content_start = read_chunk_header(offset)
            if chunk_id == 'LIST':
                form_type = data[content_start:content_start+4].decode('ascii', errors='ignore')
                if form_type == 'pdta':
                    pdta_chunks = {}
                    pdta_offset = content_start + 4
                    end = offset + 8 + size
                    while pdta_offset < end:
                        sub_id, sub_size, sub_start = read_chunk_header(pdta_offset)
                        pdta_chunks[sub_id] = (sub_start, sub_size)
                        pdta_offset = sub_start + sub_size
                        if sub_size % 2 == 1:
                            pdta_offset += 1
                    return pdta_chunks
            offset = content_start + size
            if size % 2 == 1:
                offset += 1
        return {}

    pdta = find_pdta_chunks()
    if 'phdr' not in pdta:
        return {}

    start, size = pdta['phdr']
    count = size // 38
    drumset_names = {}
    for i in range(count):
        entry = data[start + i*38 : start + (i+1)*38]
        name = entry[0:20].split(b'\x00')[0].decode('ascii', errors='ignore').strip()
        preset, bank = struct.unpack('<HH', entry[20:24])
        if bank == 128:
            drumset_names[preset] = name
    return drumset_names

def annotate_cfg_inplace(cfg_path, sf2_path):
    drumset_names = extract_drumset_names(sf2_path)
    if not drumset_names:
        print("bank 128 のプリセットが見つからなかったため、cfg は変更されませんでした。")
        return

    with open(cfg_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    updated_lines = []
    for line in lines:
        match = re.match(r"^(drumset\s+)(\d+)(.*)", line.strip())
        if match:
            prefix, num_str, rest = match.groups()
            num = int(num_str)
            if num in drumset_names:
                name = drumset_names[num]
                updated_lines.append(f"{prefix}{num} # {name}\n")
            else:
                updated_lines.append(line)
        else:
            updated_lines.append(line)

    with open(cfg_path, 'w', encoding='utf-8') as f:
        f.writelines(updated_lines)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("使用方法: add_comment_to_drumset.py input.cfg input.sf2")
        sys.exit(1)

    cfg_path = sys.argv[1]
    sf2_path = sys.argv[2]
    annotate_cfg_inplace(cfg_path, sf2_path)
