@echo off
if "%~2" == "" goto usage
if not "%~3" == "" goto usage
goto main

:usage
echo.
echo �g�p���@�F %~nx0  ����.pdf  �o��.pdf
goto :eof

:main
echo on
qpdf --qdf --object-streams=disable %1 ~temp1.qdf
sd -f s "/XObject\s*<<.*?>>" "" < ~temp1.qdf | sd "/[A-Za-z0-9.]{2,}\s+Do" "" > ~temp2.qdf
cpdf -squeeze ~temp2.qdf -o %2
del ~temp1.qdf
del ~temp2.qdf
