# 背景が白の画像から写真等の矩形の座標を標準出力に書き出す.
# jbig2.exe -S で書き出されるpngファイルを対象として作成したが、そのファイルのサイズは縦横共 元画像サイズ div 16 * 16 になっていて右と下がカットされている。
# よって左上を原点として見て座標に影響はしない.
# Geminiが作成したスクリプトを少し変更.

# インストールするパッケージ
# pip install opencv-python

import sys
import os
import cv2
import numpy as np

def get_rects(image_path):
    img = cv2.imread(image_path)
    if img is None:
        print(f"エラー: {image_path} を読み込めませんでした.")
        return

    img_h, img_w, _ = img.shape

    # 1. 250以下の色がある部分を二値化（画像は一切加工せず綺麗なまま）
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 250, 255, cv2.THRESH_BINARY_INV)

    # 2. 輪郭を抽出
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    final_rects = []

    for c in contours:
        x, y, w, h = cv2.boundingRect(c)

        # 独立した小さなゴミは最初から除外
        if w < 50 or h < 50:
            continue

        # 3. 縦に伸びたL字型ノイズを検出して、写真の「本当の高さ」を割り出す
        # 検出された四角形（threshの切り抜き）を、1行（1ピクセル）ずつ上から下へスキャンします
        roi = thresh[y:y+h, x:x+w]

        real_h = h
        # 下から上に向かってスキャンし、「横方向のドットの数が、写真の本来の幅(w)に対して極端に少ない（＝ただの細い縦線しか残っていない）行」を探します
        for row_idx in reversed(range(h)):
            # その行にある「色がついているピクセル」の数をカウント
            row_pixels = np.sum(roi[row_idx] == 255)

            # もし、その行に「幅の15%未満」しかドットがなければ、そこは写真ではなく「ただの細い縦線（ノイズ）」の区間であると判断
            if row_pixels < (w * 0.15):
                # 写真の本当の高さ（底辺）を、このノイズが始まる手前までに縮める
                real_h = row_idx
            else:
                # 写真本体のドット（分厚い塊）にぶつかったら、そこが本当の底辺なのでスキャンを終了
                break

        # 修正された高さ（real_h）が、あまりにも小さくなりすぎた場合はノイズ単体なので除外
        if real_h < 50:
            continue

        # 4. 補正された正しい四角形を登録
        final_rects.append((x, y, w, real_h))

    # 上にある順にソート
    final_rects = sorted(final_rects, key=lambda r: r[1])

    # 5. 結果出力
    for i, (x, y, w, h) in enumerate(final_rects):
        print(f"{x} {y} {w} {h}")

   # 確認用
       #cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 3)
   #cv2.imwrite("check.jpg", img)
   #print("確認用に'check.jpg'を保存しました.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("背景が白の画像から写真等の矩形の座標を書き出す.")
        print("使用方法:", os.path.basename(sys.argv[0]), "<入力画像ファイル>")
        print("")
        sys.exit(1)

    get_rects(sys.argv[1])
